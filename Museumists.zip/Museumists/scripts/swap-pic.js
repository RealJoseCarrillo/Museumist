var index = 0;

var arrayOfImages = new Array( "Map-02.jpg", "Map-03.jpg", "Map-04.jpg");
var arrayOfDescriptions = new Array( "Witte Museum", "McNay Art Museum", "San Antonio Museum of Art");
var arrayOfTitle = new Array( "Click to start the Witte Museum tour!", "Click to start the McNay Art Museum tour!","Click to start the San Antonio Museum of Art tour!");
var arrayOfLinks = new Array("topic1.html", "topic2.html", "topic3.html");

function showTheSecondOne()
{
	index = index + 1;
	
	document.getElementById( "map" ).src = "images/"+ arrayOfImages [ 0 ];
	document.getElementById( "map" ). alt = arrayOfDescriptions [ 0 ];
	document.getElementById( "map" ). title = arrayOfTitle [ 0 ];
	document.getElementById( "museumlinks" ).href = arrayOfLinks [ 0 ];
	

}


function showTheThirdOne()
{
	index = index + 1;
	document.getElementById( "map" ).src = "images/"+ arrayOfImages [ 1 ];
	document.getElementById( "map" ). alt = arrayOfDescriptions [ 1 ];
	document.getElementById( "map" ). title = arrayOfTitle [ 1 ];
	document.getElementById( "museumlinks" ).href = arrayOfLinks [ 1 ];
}


function showTheFourthOne()
{
	index = index + 1;
	document.getElementById( "map" ).src = "images/"+ arrayOfImages [ 2 ];
	document.getElementById( "map" ). alt = arrayOfDescriptions [ 2 ];
	document.getElementById( "map" ). title = arrayOfTitle [ 2 ];
	document.getElementById( "museumlinks" ).href = arrayOfLinks [ 2 ];
}

