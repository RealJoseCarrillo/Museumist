// This function processes the quiz data

function submitQuiz1()
{

	var score = 0;
	
	var q1 = document.forms.quiz1.one;
	var q2 = document.forms.quiz1.two;
	var q3 = document.forms.quiz1.three;
	var q4 = document.forms.quiz1.four;	
	var q5 = document.forms.quiz1.five;
	var q6 = document.forms.quiz1.six;
	var q7 = document.forms.quiz1.seven;	
	var q8 = document.forms.quiz1.eight;
	var q9 = document.forms.quiz1.nine;
	var q10 = document.forms.quiz1.ten;
			
if( q1[ 0 ].checked == true )
	{
		//alert( "Question 1 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 1 wrong!" );
	}
	
	
if( q2[ 1 ].checked == true )
	{
		//alert( "Question 2 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 2 wrong!" );
	}
	
if( q3[ 2 ].checked == true )
	{
		//alert( "Question 3 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 3 wrong!" );
	}
if( q4[ 0 ].checked == true )
	{
		//alert( "Question 4 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 4 wrong!" );
	}
	
	
if( q5[ 1 ].checked == true )
	{
		//alert( "Question 5 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 5 wrong!" );
	}
	
	
if( q6[ 2 ].checked == true )
	{
		//alert( "Question 6 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 6 wrong!" );
	}
	
	
if( q7[ 2 ].checked == true )
	{
		//alert( "Question 7 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 7 wrong!" );
	}
	
if( q8[ 0 ].checked == true )
	{
		//alert( "Question 8 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 8 wrong!" );
	}
	
	
if( q9[ 1 ].checked == true )
	{
		//alert( "Question 9 correct!" );
		
		score = score + 10;
	}
	else
	{
		//alert( "Question 9 wrong!" );
	}
	
if( q10[ 2 ].checked == true )
	{
		//alert( "Question 10 correct!" );
		
		score = score + 10;

	}
	else
	{
		//alert( "Question 10 wrong!" );
	}
	
	
	
	
//check to see if they passed		
if( score >= 70 )
	{
		
// here in my code, score is now a value between 0 and 100 	
// call the function to report scores
		
		
		alert("Total Score " + score + ". You Passed! Click OK to get your Certificate!");
		window.location.href = 'certificate.html';
		
//		parent.reportScores( score );
		parent.reportScores(score);


	}
		
	else
	{

				
		alert("Total Score: " + score + ". Uh oh... We have an issue...");
		window.location.href = 'retry.html';
		
	}	
	


}

